import requests as r
import json
from datetime import datetime
def convert_to_hours(timestamp):
    dt = datetime.fromtimestamp(timestamp)
    return ("{}:{}:{}".format(str(dt.hour).zfill(2),str(dt.minute).zfill(2),str(dt.second).zfill(2)))

def convert_to_date(timestamp):
    dt = datetime.fromtimestamp(timestamp)
    return ("{}:{}:{}".format(str(dt.day).zfill(2),str(dt.month).zfill(2),str(dt.year).zfill(2)))


BOT_TOKEN = "1836204407:AAGwGbW1uMEFJ_hWOJmhy0CT-ruPT8Z1BV8"

TELEGRAM_URL = F"https://api.telegram.org/bot{BOT_TOKEN}/getUpdates"

response = r.get(TELEGRAM_URL)
data = json.loads(response.text)
new_list = []
for i in data['result']:
    data = {"text": i['message']['text'],"date":convert_to_date(i['message']['date']), "time": convert_to_hours(i['message']['date']),'user_Id':i['message']['chat']['id'], 'name': i['message']['chat']['first_name']}
    
    new_list.append(data)
# print(new_list)
with open("data.json", "w") as file:
    data = {
        "messages": new_list
    }
    json.dump(data, file, indent=4)

# {'message_id': 13, 'from': {'id': 1006924918, 'is_bot': False, 'first_name': 'Кодиров', 'username': 'Kodirov_97', 'language_code': 'ru'}, 'chat': {'id': 1006924918, 'first_name': 'Кодиров', 'username': 'Kodirov_97', 'type': 'private'}, 'date': 1622573241, 'text': 'что там'}