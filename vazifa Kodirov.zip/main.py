import requests as r
import json

# from config import BOT_TOKEN

# https://api.telegram.org/bot<token>/METHOD_NAME
BOT_TOKEN = "1836204407:AAGwGbW1uMEFJ_hWOJmhy0CT-ruPT8Z1BV8"


url = F"https://api.telegram.org/bot{BOT_TOKEN}/getUpdates"

javob = r.get(url)
data = json.loads(javob.text)

len_list = len(data['result'])
# print(len_list)

while True:
    javob = r.get(url)
    data = json.loads(javob.text)
    msg = data['result'][-1]['message']['text']
    if len_list != len(data['result']):
        print(msg)
        len_list = len(data['result'])
